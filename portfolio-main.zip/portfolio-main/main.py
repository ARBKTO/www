#Импорт
from flask import Flask, render_template,request, redirect

from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
#Подключение SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#Создание db
db = SQLAlchemy(app)
#Создание таблицы



class Card(db.Model):
    #Создание полей
    #id
    id = db.Column(db.Integer, primary_key=True)
    #Заголовок
    email = db.Column(db.String(100), nullable=False)
    #Описание
   
    #Текст
    text = db.Column(db.Text, nullable=False)

    #Вывод объекта и id
    def __repr__(self):
        return f'<Card {self.id}>'
    

#Запуск страницы с контентом
@app.route('/')
def index():
    return render_template('index.html')


#Запуск страницы с контентом
@app.route('/koment')
def koment():
    #Отображение объектов из БД
    cards = Card.query.order_by(Card.id).all()

    return render_template('koment.html', cards=cards)


#Запуск страницы c картой
@app.route('/card/<int:id>')
def card(id):
    card = Card.query.get(id)

    return render_template('card.html', card=card)


#Форма карты
@app.route('/form_create', methods=['GET','POST'])
def form_create():
    if request.method == 'POST':
        subtitle =  request.form['subtitle']
        text =  request.form['text']



#Запуск страницы с контентом
#Динамичные скиллы
@app.route('/', methods=['POST'])
def process_form():
    button_python = request.form.get('button_python')
    button_discord = request.form.get('button_discord')
    button_html = request.form.get('button_html')
    button_db = request.form.get('button_db')
    return render_template('index.html', button_python=button_python, button_discord=button_discord, button_html=button_html,button_db=button_db)


#Результаты формы
@app.route('/koment', methods=['POST'])
def submit_form():
    #Создай переменные для сбора информации
    email = request.form['email']
    text = request.form['text']
    # with open('form.txt', 'a',) as f:
    #     f.write(F'text:{text} , email: {email} , \n')
    card = Card(email=email, text=text)

    db.session.add(card)
    db.session.commit()


    # здесь вы можете сохранить данные или отправить их по электронной почте
    return render_template('index.html', 
                           #Помести переменные
                           email = email,
                           text = text

                           )






if __name__ == "__main__":
    app.run(debug=True)